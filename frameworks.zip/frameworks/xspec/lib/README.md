## [`iso-schematron`](iso-schematron/)

Taken from `https://github.com/Schematron/schematron/tree/2020-10-01/trunk/schematron/code`.
